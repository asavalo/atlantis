# SVF-Teaching
Learning and Teaching Software Analysis, Verification and AI via [SVF](https://github.com/SVF-tools/SVF)

[Software Security Analysis Course](https://github.com/SVF-tools/Software-Security-Analysis) (new!)

[Software Analysis Course](https://github.com/SVF-tools/Teaching-Software-Analysis)

[Software Verification Course](https://github.com/SVF-tools/Teaching-Software-Verification)
